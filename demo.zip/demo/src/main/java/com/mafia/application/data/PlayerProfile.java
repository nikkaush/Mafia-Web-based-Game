package com.mafia.application.data;

public class PlayerProfile {

	String pid;
	String pname;

	public String getPid() {
		return pid;
	}

//	public void setPid(String pid) {
//		this.pid = pid;
//	}

	public String getPname() {
		return pname;
	}

//	public void setPname(String pname) {
//		this.pname = pname;
//	}

	

}
