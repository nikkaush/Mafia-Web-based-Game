package com.mafia.application.data;

import java.util.List;

public class Result {
	
	List<Integer> winnerList;
	List<Integer> loserList;

}
